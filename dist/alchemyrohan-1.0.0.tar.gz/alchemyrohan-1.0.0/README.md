
# Alchemyrohan 
--

Alchemyrohan is an extension package for SqlAlchemy[^1] where the python code of the database models is created automatically according to the database schema.

[^1]: [sqlalchemy](https://www.sqlalchemy.org/)

# How to Install
--

The package is currently not available on the PyPi. Therefore, you can download the tar 
