

"""

AlchemyRohan is package where...



Starting point is < assemble_model > function.

"""


__author__ = 'Alan Wamberger'
__version__ = '1.0.0'
__license__ = 'MIT'


from alchemyrohan.assemble import *
from alchemyrohan.utils import *